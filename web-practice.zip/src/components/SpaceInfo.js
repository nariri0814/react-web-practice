import React, { useState } from 'react'
import './SpaceInfo.css'

const SpaceInfo = () => {
    const SpaceImgSrc = [
        "../img/space_01.png",
        "../img/space_02.png",
        "../img/space_03.png",
        "../img/space_04.png",
        "../img/space_05.png",
        "../img/space_06.png",
        "../img/space_07.png",
        "../img/space_08.png",
        "../img/space_09.png",
        "../img/space_10.png"
    ]
    const onClickBtn = () => {
        const SpaceImg = document.querySelector('.space_img_sec img');
        const ImgSrc = () => {
            SpaceImg.target.src = SpaceImgSrc[2]
        }
    }
    return (
        <>
        <div className="space_info">
            <div className="space_tit">
                <div className="space_tit_L">
                    <h2>경기생활문화센터<br/>공간소개</h2>
                    <p>경기생활문화센터에서 운영하는 공간을 둘러보세요.</p>
                </div>
                <div className="space_tit_R">
                    <div className="space_more">MORE</div>
                </div>
            </div>
            <div className="space_main_sec">
                <div className="space_btn_sec">
                    <div className="sp_btn_wrap">
                        <div className="sp_btn" onClick={onClickBtn}>책 놀이터</div>
                        <div className="sp_btn" onClick={onClickBtn}>생활 수유실</div>
                    </div>
                    <div className="sp_btn_wrap">
                        <div className="sp_btn" onClick={onClickBtn}>동네부엌</div>
                        <div className="sp_btn" onClick={onClickBtn}>생생 수유실</div>
                        <div className="sp_btn" onClick={onClickBtn}>마주침 공간1</div>
                        <div className="sp_btn" onClick={onClickBtn}>아주침 공간2</div>
                    </div>
                    <div className="sp_btn_wrap">
                        <div className="sp_btn" onClick={onClickBtn}>한뼘전시</div>
                        <div className="sp_btn" onClick={onClickBtn}>무아지경</div>
                        <div className="sp_btn" onClick={onClickBtn}>생생살롱1</div>
                        <div className="sp_btn" onClick={onClickBtn}>생생살롱2</div>
                    </div>
                </div>
                <div className="space_img_sec">
                    <img src="../img/space_01.png" alt="space"/>
                </div>
            </div>
        </div>
        <div className="space_tit our_space">
            <div className="space_tit_L">
                <h2>우리지역<br/>생활문화공간을 찾아보세요</h2>
                <p>내가 사는 지역 생활문화공간 바로 찾기</p>
            </div>
            <img src="../img/our-center-img.svg" alt="our_space"/>
            <div className="space_tit_R">
                <div className="space_more">MORE</div>
            </div>
        </div>
        </>
    )
}

export default SpaceInfo
